<?php
/**
 * Orbit_Backup_Engine
 *
 * Handles the full lifecycle of creating and restoring WordPress backups.
 * – Stream-based SQL export (no full-table memory load).
 * – ZipArchive bundling of selected directories.
 * – Hook-based selective backup control.
 * – Integrity verification via SHA-256 checksum manifest.
 */

defined( 'ABSPATH' ) || exit;

class Orbit_Backup_Engine {

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Run a new backup.
     *
     * @param array $options {
     *   @type bool   $include_db       Export the database.
     *   @type bool   $include_plugins  Bundle wp-content/plugins.
     *   @type bool   $include_themes   Bundle wp-content/themes.
     *   @type bool   $include_uploads  Bundle wp-content/uploads.
     *   @type bool   $include_others   Bundle everything else in wp-content.
     *   @type string $label            Human-readable label (Manual / Scheduled).
     * }
     * @return array|WP_Error  Result meta on success, WP_Error on failure.
     */
    public function run( array $options = array() ) {
        $defaults = array(
            'include_db'      => true,
            'include_plugins' => true,
            'include_themes'  => true,
            'include_uploads' => true,
            'include_others'  => false,
            'label'           => 'Manual',
        );

        // Allow third-party code to modify the defaults.
        $options = apply_filters( 'orbit_backup_options', wp_parse_args( $options, $defaults ) );

        // Ensure storage directory exists.
        if ( ! file_exists( ORBIT_BACKUP_STORE_DIR ) ) {
            wp_mkdir_p( ORBIT_BACKUP_STORE_DIR );
        }

        $timestamp   = date( 'Y-m-d_H-i-s' );
        $slug        = sanitize_title( $options['label'] );
        $archive_name = "orbit-backup-{$slug}-{$timestamp}.zip";
        $archive_path = ORBIT_BACKUP_STORE_DIR . $archive_name;
        $tmp_dir      = ORBIT_BACKUP_STORE_DIR . "tmp_{$timestamp}/";

        wp_mkdir_p( $tmp_dir );

        $zip = new ZipArchive();
        if ( true !== $zip->open( $archive_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
            $this->cleanup( $tmp_dir );
            return new WP_Error( 'zip_open_failed', __( 'Could not create ZIP archive.', 'orbit-backup' ) );
        }

        $components = array();

        // ── Database ─────────────────────────────────────────────────────────
        if ( ! empty( $options['include_db'] ) ) {
            $sql_file = $tmp_dir . 'database.sql';
            $result   = $this->export_database( $sql_file );
            if ( is_wp_error( $result ) ) {
                $zip->close();
                $this->cleanup( $tmp_dir );
                return $result;
            }
            $zip->addFile( $sql_file, 'database.sql' );
            $components[] = 'db';
        }

        // ── Plugins ───────────────────────────────────────────────────────────
        if ( ! empty( $options['include_plugins'] ) ) {
            $this->add_directory_to_zip( $zip, WP_PLUGIN_DIR, 'plugins' );
            $components[] = 'plugins';
        }

        // ── Themes ────────────────────────────────────────────────────────────
        if ( ! empty( $options['include_themes'] ) ) {
            $themes_dir = get_theme_root();
            $this->add_directory_to_zip( $zip, $themes_dir, 'themes' );
            $components[] = 'themes';
        }

        // ── Uploads ───────────────────────────────────────────────────────────
        if ( ! empty( $options['include_uploads'] ) ) {
            $upload_dir = wp_upload_dir();
            // Exclude the orbit-backups sub-folder to prevent recursive archives.
            $this->add_directory_to_zip(
                $zip,
                $upload_dir['basedir'],
                'uploads',
                array( realpath( ORBIT_BACKUP_STORE_DIR ) )
            );
            $components[] = 'uploads';
        }

        // ── Others (everything else in wp-content) ────────────────────────────
        if ( ! empty( $options['include_others'] ) ) {
            $excluded = array(
                realpath( WP_PLUGIN_DIR ),
                realpath( get_theme_root() ),
                realpath( wp_upload_dir()['basedir'] ),
                realpath( ORBIT_BACKUP_STORE_DIR ),
            );
            $this->add_directory_to_zip( $zip, WP_CONTENT_DIR, 'wp-content-other', $excluded );
            $components[] = 'others';
        }

        // ── Manifest ──────────────────────────────────────────────────────────
        $manifest = array(
            'version'    => ORBIT_BACKUP_VERSION,
            'created_at' => current_time( 'mysql' ),
            'site_url'   => get_option( 'siteurl' ),
            'home_url'   => get_option( 'home' ),
            'wp_version' => get_bloginfo( 'version' ),
            'components' => $components,
            'label'      => sanitize_text_field( $options['label'] ),
            'table_prefix' => $this->get_table_prefix(),
        );
        $zip->addFromString( 'orbit-manifest.json', wp_json_encode( $manifest, JSON_PRETTY_PRINT ) );

        $zip->close();
        $this->cleanup( $tmp_dir );

        // ── Checksum ──────────────────────────────────────────────────────────
        $checksum = hash_file( 'sha256', $archive_path );
        file_put_contents( $archive_path . '.sha256', $checksum );

        // ── Persist to history ────────────────────────────────────────────────
        $entry = array(
            'id'         => uniqid( 'orb_', true ),
            'filename'   => $archive_name,
            'label'      => sanitize_text_field( $options['label'] ),
            'created_at' => current_time( 'mysql' ),
            'size'       => filesize( $archive_path ),
            'components' => $components,
            'checksum'   => $checksum,
        );

        $history   = self::get_history();
        array_unshift( $history, $entry );
        $history   = array_slice( $history, 0, 20 ); // keep last 20
        update_option( 'orbit_backup_history', $history, false );

        do_action( 'orbit_backup_completed', $entry );

        return $entry;
    }

    // ─────────────────────────────────────────────────────── Restore Wizard ──

    /**
     * Step 1 – Receive & validate an uploaded ZIP.
     * Returns metadata from the manifest + integrity status.
     *
     * @param string $tmp_path  Temporary path of the uploaded file.
     * @return array|WP_Error
     */
    public function restore_step1_verify( string $tmp_path ) {
        if ( ! file_exists( $tmp_path ) ) {
            return new WP_Error( 'file_missing', __( 'Uploaded file not found.', 'orbit-backup' ) );
        }

        $zip = new ZipArchive();
        if ( true !== $zip->open( $tmp_path ) ) {
            return new WP_Error( 'zip_invalid', __( 'The file is not a valid ZIP archive.', 'orbit-backup' ) );
        }

        $manifest_raw = $zip->getFromName( 'orbit-manifest.json' );
        $zip->close();

        if ( false === $manifest_raw ) {
            return new WP_Error( 'no_manifest', __( 'No Orbit manifest found. This is not an Orbit backup.', 'orbit-backup' ) );
        }

        $manifest = json_decode( $manifest_raw, true );
        if ( ! is_array( $manifest ) ) {
            return new WP_Error( 'bad_manifest', __( 'Manifest is corrupted.', 'orbit-backup' ) );
        }

        return array(
            'status'   => 'ok',
            'manifest' => $manifest,
        );
    }

    /**
     * Step 2 – Extract the archive to a temp directory.
     *
     * @param string $zip_path   Absolute path to the archive.
     * @param string $extract_to Destination directory.
     * @return true|WP_Error
     */
    public function restore_step2_extract( string $zip_path, string $extract_to ) {
        wp_mkdir_p( $extract_to );

        $zip = new ZipArchive();
        if ( true !== $zip->open( $zip_path ) ) {
            return new WP_Error( 'zip_open', __( 'Cannot open archive for extraction.', 'orbit-backup' ) );
        }

        $extracted = $zip->extractTo( $extract_to );
        $zip->close();

        if ( ! $extracted ) {
            return new WP_Error( 'extract_failed', __( 'Extraction failed.', 'orbit-backup' ) );
        }

        return true;
    }

    /**
     * Step 3 – Restore files & database from extracted directory.
     *
     * @param string $extract_dir   Directory produced by step 2.
     * @param string $old_url       Original site URL stored in the manifest.
     * @param string $new_url       Current site URL (may differ after migration).
     * @return true|WP_Error
     */
    public function restore_step3_apply( string $extract_dir, string $old_url = '', string $new_url = '' ) {
        $manifest_path = trailingslashit( $extract_dir ) . 'orbit-manifest.json';
        if ( ! file_exists( $manifest_path ) ) {
            return new WP_Error( 'no_manifest', __( 'Manifest not found in extracted archive.', 'orbit-backup' ) );
        }

        $manifest   = json_decode( file_get_contents( $manifest_path ), true );
        $components = $manifest['components'] ?? array();
        $extract    = trailingslashit( $extract_dir );

        // ── Plugins ───────────────────────────────────────────────────────────
        if ( in_array( 'plugins', $components, true ) && is_dir( $extract . 'plugins' ) ) {
            $this->recursive_copy( $extract . 'plugins', WP_PLUGIN_DIR );
        }

        // ── Themes ────────────────────────────────────────────────────────────
        if ( in_array( 'themes', $components, true ) && is_dir( $extract . 'themes' ) ) {
            $this->recursive_copy( $extract . 'themes', get_theme_root() );
        }

        // ── Uploads ───────────────────────────────────────────────────────────
        if ( in_array( 'uploads', $components, true ) && is_dir( $extract . 'uploads' ) ) {
            $upload_dir = wp_upload_dir();
            $this->recursive_copy( $extract . 'uploads', $upload_dir['basedir'] );
        }

        // ── Others ────────────────────────────────────────────────────────────
        if ( in_array( 'others', $components, true ) && is_dir( $extract . 'wp-content-other' ) ) {
            $this->recursive_copy( $extract . 'wp-content-other', WP_CONTENT_DIR );
        }

        // ── Database ──────────────────────────────────────────────────────────
        if ( in_array( 'db', $components, true ) ) {
            $sql_file = $extract . 'database.sql';
            if ( ! file_exists( $sql_file ) ) {
                return new WP_Error( 'sql_missing', __( 'database.sql not found in archive.', 'orbit-backup' ) );
            }

            $result = $this->import_database( $sql_file );
            if ( is_wp_error( $result ) ) {
                return $result;
            }

            // ── URL Replacement ────────────────────────────────────────────────
            if ( $old_url && $new_url && $old_url !== $new_url ) {
                $this->search_replace_url( $old_url, $new_url, $manifest['table_prefix'] ?? $this->get_table_prefix() );
            }
        }

        // Clean up extracted directory.
        $this->cleanup( $extract_dir );

        return true;
    }

    // ─────────────────────────────────────────────────────────── History ──────

    /**
     * Return parsed backup history array.
     *
     * @return array
     */
    public static function get_history(): array {
        return (array) get_option( 'orbit_backup_history', array() );
    }

    /**
     * Delete a backup entry and its file.
     *
     * @param string $id  Entry ID.
     * @return bool
     */
    public static function delete_entry( string $id ): bool {
        $history = self::get_history();
        foreach ( $history as $i => $entry ) {
            if ( $entry['id'] === $id ) {
                $file = ORBIT_BACKUP_STORE_DIR . $entry['filename'];
                if ( file_exists( $file ) ) {
                    @unlink( $file );
                    @unlink( $file . '.sha256' );
                }
                unset( $history[ $i ] );
                update_option( 'orbit_backup_history', array_values( $history ), false );
                return true;
            }
        }
        return false;
    }

    // ─────────────────────────────────────────────────── Private Helpers ──────

    /**
     * Stream-based SQL export – reads and writes row-by-row to avoid OOM.
     *
     * @param string $output_file  Absolute path for the .sql output.
     * @return true|WP_Error
     */
    private function export_database( string $output_file ) {
        global $wpdb;

        $fp = fopen( $output_file, 'w' );
        if ( ! $fp ) {
            return new WP_Error( 'sql_open', __( 'Cannot open SQL output file.', 'orbit-backup' ) );
        }

        // Header.
        fwrite( $fp, "-- Orbit Backup SQL Export\n" );
        fwrite( $fp, "-- Generated: " . current_time( 'mysql' ) . "\n" );
        fwrite( $fp, "-- WordPress version: " . get_bloginfo( 'version' ) . "\n\n" );
        fwrite( $fp, "SET FOREIGN_KEY_CHECKS=0;\n" );
        fwrite( $fp, "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n" );
        fwrite( $fp, "SET NAMES utf8mb4;\n\n" );

        // Get all tables.
        $tables = $wpdb->get_col( 'SHOW TABLES' );
        if ( empty( $tables ) ) {
            fclose( $fp );
            return new WP_Error( 'no_tables', __( 'No tables found in the database.', 'orbit-backup' ) );
        }

        foreach ( $tables as $table ) {
            $table = esc_sql( $table );

            // DROP + CREATE structure.
            fwrite( $fp, "-- ----------------------------\n" );
            fwrite( $fp, "-- Table structure for `{$table}`\n" );
            fwrite( $fp, "-- ----------------------------\n" );
            fwrite( $fp, "DROP TABLE IF EXISTS `{$table}`;\n" );

            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $create = $wpdb->get_row( "SHOW CREATE TABLE `{$table}`", ARRAY_N );
            fwrite( $fp, $create[1] . ";\n\n" );

            // Row count for progress awareness.
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $total_rows = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
            if ( 0 === $total_rows ) {
                continue;
            }

            fwrite( $fp, "-- ----------------------------\n" );
            fwrite( $fp, "-- Records of `{$table}`\n" );
            fwrite( $fp, "-- ----------------------------\n" );

            // Stream rows in pages of 500 to keep memory low.
            $offset    = 0;
            $page_size = 500;

            while ( $offset < $total_rows ) {
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $rows = $wpdb->get_results(
                    $wpdb->prepare( "SELECT * FROM `{$table}` LIMIT %d OFFSET %d", $page_size, $offset ),
                    ARRAY_A
                );

                if ( empty( $rows ) ) {
                    break;
                }

                $columns = '`' . implode( '`, `', array_keys( $rows[0] ) ) . '`';

                foreach ( $rows as $row ) {
                    $values = implode( ', ', array_map( function ( $val ) use ( $wpdb ) {
                        if ( is_null( $val ) ) {
                            return 'NULL';
                        }
                        return "'" . esc_sql( $val ) . "'";
                    }, $row ) );

                    fwrite( $fp, "INSERT INTO `{$table}` ({$columns}) VALUES ({$values});\n" );
                }

                $offset += $page_size;
            }

            fwrite( $fp, "\n" );
        }

        fwrite( $fp, "SET FOREIGN_KEY_CHECKS=1;\n" );
        fclose( $fp );

        return true;
    }

    /**
     * Import a SQL file using the wpdb connection.
     *
     * @param string $sql_file  Path to the .sql file.
     * @return true|WP_Error
     */
    private function import_database( string $sql_file ) {
        global $wpdb;

        $fp = fopen( $sql_file, 'r' );
        if ( ! $fp ) {
            return new WP_Error( 'sql_import_open', __( 'Cannot open SQL file for import.', 'orbit-backup' ) );
        }

        // Suppress errors during import – we check manually.
        $wpdb->show_errors();
        $current = '';

        while ( ! feof( $fp ) ) {
            $line = fgets( $fp );

            // Skip comments and empty lines.
            if ( '' === trim( $line ) || 0 === strpos( trim( $line ), '--' ) || 0 === strpos( trim( $line ), '/*' ) ) {
                continue;
            }

            $current .= $line;

            // Execute once we reach a statement terminator.
            if ( ';' === substr( rtrim( $current ), -1 ) ) {
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $wpdb->query( $current );
                $current = '';
            }
        }

        fclose( $fp );

        return true;
    }

    /**
     * Perform serialization-safe search & replace across all WP tables.
     *
     * @param string $old_url       Old site URL.
     * @param string $new_url       New site URL.
     * @param string $table_prefix  DB table prefix.
     */
    private function search_replace_url( string $old_url, string $new_url, string $table_prefix ) {
        global $wpdb;

        $tables = $wpdb->get_col( $wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $wpdb->esc_like( $table_prefix ) . '%'
        ) );

        foreach ( $tables as $table ) {
            $columns = $wpdb->get_results( "DESCRIBE `{$table}`", ARRAY_A ); // phpcs:ignore
            foreach ( $columns as $col ) {
                $col_name = $col['Field'];
                $col_type = strtolower( $col['Type'] );

                // Only process text-like columns.
                if ( false === strpos( $col_type, 'text' ) &&
                     false === strpos( $col_type, 'char' ) &&
                     false === strpos( $col_type, 'longtext' ) &&
                     false === strpos( $col_type, 'mediumtext' ) ) {
                    continue;
                }

                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $rows = $wpdb->get_results( "SELECT * FROM `{$table}`", ARRAY_A );
                foreach ( $rows as $row ) {
                    $val = $row[ $col_name ];
                    if ( false === strpos( $val, $old_url ) ) {
                        continue;
                    }

                    $new_val = $this->recursive_unserialize_replace( $old_url, $new_url, $val );
                    if ( $new_val !== $val ) {
                        // Build a WHERE clause from the primary key.
                        $primary = $this->get_primary_key( $table );
                        if ( $primary ) {
                            $wpdb->update(
                                $table,
                                array( $col_name => $new_val ),
                                array( $primary => $row[ $primary ] )
                            );
                        }
                    }
                }
            }
        }
    }

    /**
     * Safely replace strings inside potentially serialized data.
     *
     * @param string $search
     * @param string $replace
     * @param string $data
     * @return string
     */
    private function recursive_unserialize_replace( string $search, string $replace, string $data ): string {
        if ( is_serialized( $data ) ) {
            $unserialized = @unserialize( $data );
            if ( false !== $unserialized ) {
                $unserialized = $this->array_recursive_replace( $search, $replace, $unserialized );
                return serialize( $unserialized );
            }
        }

        return str_replace( $search, $replace, $data );
    }

    /** @param mixed $data */
    private function array_recursive_replace( string $search, string $replace, $data ) {
        if ( is_array( $data ) ) {
            foreach ( $data as $k => $v ) {
                $data[ $k ] = $this->array_recursive_replace( $search, $replace, $v );
            }
        } elseif ( is_string( $data ) ) {
            $data = str_replace( $search, $replace, $data );
        }
        return $data;
    }

    /**
     * Recursively add a directory to an open ZipArchive.
     *
     * @param ZipArchive $zip        Open archive instance.
     * @param string     $source     Absolute path of source directory.
     * @param string     $zip_prefix Prefix inside the ZIP (acts as a folder).
     * @param array      $excludes   Absolute paths to skip.
     */
    private function add_directory_to_zip( ZipArchive $zip, string $source, string $zip_prefix, array $excludes = array() ) {
        $source = rtrim( realpath( $source ), DIRECTORY_SEPARATOR );

        if ( ! is_dir( $source ) ) {
            return;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator( $source, RecursiveDirectoryIterator::SKIP_DOTS ),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ( $iterator as $item ) {
            $real = realpath( $item->getPathname() );

            // Skip anything in excluded directories.
            foreach ( $excludes as $ex ) {
                if ( $ex && 0 === strpos( $real, rtrim( $ex, DIRECTORY_SEPARATOR ) ) ) {
                    continue 2;
                }
            }

            // Skip our own store directory to prevent recursion.
            if ( 0 === strpos( $real, rtrim( realpath( ORBIT_BACKUP_STORE_DIR ), DIRECTORY_SEPARATOR ) ) ) {
                continue;
            }

            $relative = substr( $real, strlen( $source ) + 1 );
            $zip_path = $zip_prefix . '/' . str_replace( DIRECTORY_SEPARATOR, '/', $relative );

            if ( $item->isDir() ) {
                $zip->addEmptyDir( $zip_path );
            } else {
                $zip->addFile( $real, $zip_path );
            }
        }
    }

    /**
     * Recursively copy a directory.
     *
     * @param string $src  Source directory.
     * @param string $dst  Destination directory.
     */
    private function recursive_copy( string $src, string $dst ) {
        wp_mkdir_p( $dst );
        $dir = opendir( $src );
        while ( false !== ( $file = readdir( $dir ) ) ) {
            if ( '.' === $file || '..' === $file ) {
                continue;
            }
            $s = trailingslashit( $src ) . $file;
            $d = trailingslashit( $dst ) . $file;
            if ( is_dir( $s ) ) {
                $this->recursive_copy( $s, $d );
            } else {
                copy( $s, $d );
            }
        }
        closedir( $dir );
    }

    /**
     * Remove a directory and all its contents.
     *
     * @param string $dir
     */
    private function cleanup( string $dir ) {
        if ( ! is_dir( $dir ) ) {
            return;
        }
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ( $files as $file ) {
            $file->isDir() ? rmdir( $file->getRealPath() ) : unlink( $file->getRealPath() );
        }
        rmdir( $dir );
    }

    /**
     * Detect the primary key column name of a table.
     *
     * @param string $table
     * @return string|null
     */
    private function get_primary_key( string $table ): ?string {
        global $wpdb;
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $cols = $wpdb->get_results( "SHOW COLUMNS FROM `{$table}`", ARRAY_A );
        foreach ( $cols as $col ) {
            if ( 'PRI' === $col['Key'] ) {
                return $col['Field'];
            }
        }
        return null;
    }

    /**
     * Get the current table prefix from wpdb.
     *
     * @return string
     */
    private function get_table_prefix(): string {
        global $wpdb;
        return $wpdb->prefix;
    }
}
