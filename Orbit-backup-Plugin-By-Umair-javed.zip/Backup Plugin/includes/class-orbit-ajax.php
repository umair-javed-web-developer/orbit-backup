<?php
/**
 * Orbit_Backup_Ajax
 *
 * Registers and handles all wp_ajax_* actions for the Orbit Backup plugin.
 * Every handler verifies the nonce and capability before processing.
 */

defined( 'ABSPATH' ) || exit;

class Orbit_Backup_Ajax {

    public function __construct() {
        // Backup creation.
        add_action( 'wp_ajax_orbit_run_backup',       array( $this, 'run_backup' ) );
        // Restore wizard steps.
        add_action( 'wp_ajax_orbit_restore_verify',   array( $this, 'restore_verify' ) );
        add_action( 'wp_ajax_orbit_restore_apply',    array( $this, 'restore_apply' ) );
        // History management.
        add_action( 'wp_ajax_orbit_get_history',      array( $this, 'get_history' ) );
        add_action( 'wp_ajax_orbit_delete_backup',    array( $this, 'delete_backup' ) );
        // Download (signed URL approach).
        add_action( 'wp_ajax_orbit_download_backup',  array( $this, 'download_backup' ) );
        // Scheduling.
        add_action( 'wp_ajax_orbit_save_schedule',    array( $this, 'save_schedule' ) );
        // Security.
        add_action( 'wp_ajax_orbit_set_security',     array( $this, 'set_security' ) );
        add_action( 'wp_ajax_orbit_verify_security',  array( $this, 'verify_security' ) );
    }

    // ─────────────────────────────────────────────────── Security ────────────

    public function set_security() {
        $this->verify_request();
        $key = sanitize_text_field( $_POST['key'] ?? '' );
        update_option( 'orbit_backup_master_key', $key );
        wp_send_json_success();
    }

    public function verify_security() {
        $this->verify_request();
        $key      = sanitize_text_field( $_POST['key'] ?? '' );
        $template = get_option( 'orbit_backup_master_key' );
        
        if ( $key === $template ) {
            // In a real session we would set a transient/cookie, 
            // but for this UI we will handle it with the overlay.
            wp_send_json_success();
        } else {
            wp_send_json_error( array( 'message' => 'Invalid key' ) );
        }
    }

    // ─────────────────────────────────────────────────── Scheduling ──────────

    public function save_schedule() {
        $this->verify_request();

        $enabled   = sanitize_text_field( $_POST['enabled'] ?? '0' );
        $frequency = sanitize_text_field( $_POST['frequency'] ?? 'daily' );
        $retention = sanitize_text_field( $_POST['retention'] ?? '30' );

        $sched_data = array(
            'enabled'         => $enabled,
            'frequency'       => $frequency,
            'retention'       => $retention,
            'include_db'      => ! empty( $_POST['include_db'] ),
            'include_plugins' => ! empty( $_POST['include_plugins'] ),
            'include_themes'  => ! empty( $_POST['include_themes'] ),
            'include_uploads' => ! empty( $_POST['include_uploads'] ),
            'include_others'  => ! empty( $_POST['include_others'] ),
        );

        update_option( 'orbit_backup_schedule', $sched_data );

        // Handle WP Cron.
        wp_clear_scheduled_hook( 'orbit_backup_cron_event' );
        if ( '1' === $enabled ) {
            $recurrence = 'daily';
            if ( 'weekly' === $frequency ) $recurrence = 'weekly';
            if ( 'monthly' === $frequency ) {
                // Monthly isn't default, so let's add a filter or just use daily and check date.
                // For simplicity and WP standards, we'll stick to daily/weekly/monthly filter.
                $recurrence = $frequency;
            }
            wp_schedule_event( time() + 3600, $recurrence, 'orbit_backup_cron_event' );
        }

        wp_send_json_success( array( 'message' => __( 'Schedule settings saved.', 'orbit-backup' ) ) );
    }

    // ─────────────────────────────────────────────────── Run Backup ──────────

    public function run_backup() {
        $this->verify_request();

        // Allow plenty of time and memory for large backups.
        set_time_limit( 1200 );
        @ini_set( 'memory_limit', '512M' );

        $options = array(
            'include_db'      => ! empty( $_POST['include_db'] ),
            'include_plugins' => ! empty( $_POST['include_plugins'] ),
            'include_themes'  => ! empty( $_POST['include_themes'] ),
            'include_uploads' => ! empty( $_POST['include_uploads'] ),
            'include_others'  => ! empty( $_POST['include_others'] ),
            'label'           => 'Manual',
        );

        // Ensure at least one component is selected.
        $any = array_filter( array_values( $options ) );
        if ( empty( $any ) ) {
            wp_send_json_error( array( 'message' => __( 'Select at least one component to back up.', 'orbit-backup' ) ) );
        }

        $engine = new Orbit_Backup_Engine();
        $result = $engine->run( $options );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array(
            'entry'   => $result,
            'message' => __( 'Backup created successfully!', 'orbit-backup' ),
        ) );
    }

    // ──────────────────────────────────────────── Restore Step 1: Verify ─────

    public function restore_verify() {
        $this->verify_request();

        // Boost limits for the file processing.
        set_time_limit( 600 );
        @ini_set( 'memory_limit', '512M' );

        if ( empty( $_FILES['backup_file'] ) || UPLOAD_ERR_OK !== $_FILES['backup_file']['error'] ) {
            $err = $_FILES['backup_file']['error'] ?? 'No file';
            $msg = __( 'File upload failed.', 'orbit-backup' );
            if ( $err === UPLOAD_ERR_INI_SIZE ) {
                $msg .= ' ' . sprintf( __( 'File exceeds server limit (%s).', 'orbit-backup' ), size_format( wp_max_upload_size() ) );
            }
            wp_send_json_error( array( 'message' => $msg ) );
        }

        $tmp   = $_FILES['backup_file']['tmp_name'];
        $mime  = mime_content_type( $tmp );

        // Accept zip files only.
        $ok_mimes = array( 'application/zip', 'application/x-zip-compressed', 'application/octet-stream' );
        if ( ! in_array( $mime, $ok_mimes, true ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid file type. Only .zip archives are accepted.', 'orbit-backup' ) ) );
        }

        // Move to a temp location in our store dir.
        $dest = ORBIT_BACKUP_STORE_DIR . 'restore_upload_' . time() . '.zip';
        if ( ! move_uploaded_file( $tmp, $dest ) ) {
            wp_send_json_error( array( 'message' => __( 'Could not move uploaded file.', 'orbit-backup' ) ) );
        }

        $engine = new Orbit_Backup_Engine();
        $result = $engine->restore_step1_verify( $dest );

        if ( is_wp_error( $result ) ) {
            @unlink( $dest );
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        // Tell the client where the temp file lives so step 2 can reference it.
        $result['tmp_path'] = basename( $dest );

        wp_send_json_success( $result );
    }

    // ──────────────────────────────────────────── Restore Step 2: Apply ──────

    public function restore_apply() {
        $this->verify_request();

        // Allow plenty of time for large restores.
        set_time_limit( 1800 );
        @ini_set( 'memory_limit', '512M' );

        $tmp_file = sanitize_file_name( $_POST['tmp_file'] ?? '' );
        $old_url  = esc_url_raw( $_POST['old_url'] ?? '' );
        $new_url  = esc_url_raw( $_POST['new_url'] ?? get_option( 'siteurl' ) );

        $zip_path = ORBIT_BACKUP_STORE_DIR . $tmp_file;
        if ( ! file_exists( $zip_path ) ) {
            wp_send_json_error( array( 'message' => __( 'Temp backup file not found. Please re-upload.', 'orbit-backup' ) ) );
        }

        $extract_dir = ORBIT_BACKUP_STORE_DIR . 'restore_extract_' . time() . '/';

        $engine  = new Orbit_Backup_Engine();
        $extract = $engine->restore_step2_extract( $zip_path, $extract_dir );
        if ( is_wp_error( $extract ) ) {
            wp_send_json_error( array( 'message' => $extract->get_error_message() ) );
        }

        $apply = $engine->restore_step3_apply( $extract_dir, $old_url, $new_url );
        if ( is_wp_error( $apply ) ) {
            wp_send_json_error( array( 'message' => $apply->get_error_message() ) );
        }

        // Remove the temp upload zip.
        @unlink( $zip_path );

        wp_send_json_success( array( 'message' => __( 'Restore completed successfully! Please verify your site.', 'orbit-backup' ) ) );
    }

    // ─────────────────────────────────────────────── History & Management ────

    public function get_history() {
        $this->verify_request();
        wp_send_json_success( array( 'history' => Orbit_Backup_Engine::get_history() ) );
    }

    public function delete_backup() {
        $this->verify_request();

        $id = sanitize_text_field( $_POST['backup_id'] ?? '' );
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => __( 'No backup ID provided.', 'orbit-backup' ) ) );
        }

        $deleted = Orbit_Backup_Engine::delete_entry( $id );
        if ( ! $deleted ) {
            wp_send_json_error( array( 'message' => __( 'Backup not found.', 'orbit-backup' ) ) );
        }

        wp_send_json_success( array( 'message' => __( 'Backup deleted.', 'orbit-backup' ) ) );
    }

    public function download_backup() {
        $this->verify_request();

        $id      = sanitize_text_field( $_POST['backup_id'] ?? '' );
        $history = Orbit_Backup_Engine::get_history();

        $entry = null;
        foreach ( $history as $h ) {
            if ( $h['id'] === $id ) {
                $entry = $h;
                break;
            }
        }

        if ( ! $entry ) {
            wp_send_json_error( array( 'message' => __( 'Backup not found.', 'orbit-backup' ) ) );
        }

        $file = ORBIT_BACKUP_STORE_DIR . $entry['filename'];
        if ( ! file_exists( $file ) ) {
            wp_send_json_error( array( 'message' => __( 'Backup file not found on disk.', 'orbit-backup' ) ) );
        }

        // Return a signed download URL (valid 10 minutes).
        $token = wp_create_nonce( 'orbit_download_' . $id );
        $url   = add_query_arg( array(
            'action'     => 'orbit_stream_download',
            'backup_id'  => $id,
            '_wpnonce'   => $token,
        ), admin_url( 'admin-ajax.php' ) );

        wp_send_json_success( array( 'download_url' => $url ) );
    }

    // ─────────────────────────────────────────────────────── Helpers ──────────

    private function verify_request() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'orbit-backup' ) ), 403 );
        }

        if ( ! check_ajax_referer( 'orbit_backup_nonce', '_wpnonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Nonce verification failed.', 'orbit-backup' ) ), 403 );
        }
    }
}

// Instantiate.
new Orbit_Backup_Ajax();

// Stream download handler (no JSON, just a binary file stream).
add_action( 'wp_ajax_orbit_stream_download', 'orbit_stream_download_handler' );
function orbit_stream_download_handler() {
    $id    = sanitize_text_field( $_GET['backup_id'] ?? '' );
    $nonce = sanitize_text_field( $_GET['_wpnonce'] ?? '' );

    if ( ! current_user_can( 'manage_options' ) || ! wp_verify_nonce( $nonce, 'orbit_download_' . $id ) ) {
        wp_die( 'Unauthorized', 403 );
    }

    $history = Orbit_Backup_Engine::get_history();
    $entry   = null;
    foreach ( $history as $h ) {
        if ( $h['id'] === $id ) {
            $entry = $h;
            break;
        }
    }

    if ( ! $entry ) {
        wp_die( 'Not found', 404 );
    }

    $file = ORBIT_BACKUP_STORE_DIR . $entry['filename'];
    if ( ! file_exists( $file ) ) {
        wp_die( 'File not found', 404 );
    }

    $filename = basename( $file );
    header( 'Content-Description: File Transfer' );
    header( 'Content-Type: application/zip' );
    header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
    header( 'Content-Transfer-Encoding: binary' );
    header( 'Expires: 0' );
    header( 'Cache-Control: must-revalidate' );
    header( 'Pragma: public' );
    header( 'Content-Length: ' . filesize( $file ) );
    flush();
    readfile( $file );
    exit;
}
