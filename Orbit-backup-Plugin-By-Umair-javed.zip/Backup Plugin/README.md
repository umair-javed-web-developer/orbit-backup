# Orbit Backup & Restore

> A professional, selective WordPress backup and restore solution with a modern Bento-Grid admin dashboard.

---

## ✨ Features

| Feature | Detail |
|---|---|
| **Selective Backups** | Toggle Database, Plugins, Themes, Media, Other Files independently |
| **Stream SQL Export** | Row-by-row export in 500-row pages — no memory timeouts on large sites |
| **ZipArchive Engine** | Recursive directory bundling with exclusion support |
| **Integrity Manifest** | Every archive embeds an `orbit-manifest.json` + SHA-256 checksum |
| **4-Step Restore Wizard** | Upload → Verify → Configure → Apply with progressive disclosure |
| **URL Migration** | Serialization-safe search & replace for domain changes |
| **Modern SPA UI** | Bento-grid layout, Inter font, glassmorphism progress overlay, toast notifications |
| **Backup History** | Last 20 backups stored; 1-click Download & Delete |
| **Weekly Auto-Backup** | Optional WP-Cron scheduled backup (off by default) |
| **Security** | Nonce verification, `manage_options` capability checks, `.htaccess` protection |

---

## 📁 File Structure

```
orbit-backup/
├── orbit-backup.php              ← Core bootstrap, constants, hooks, admin menu
├── includes/
│   ├── class-orbit-engine.php   ← Backup & restore logic (Orbit_Backup_Engine)
│   └── class-orbit-ajax.php     ← All AJAX handlers (Orbit_Backup_Ajax)
├── admin/
│   ├── admin-page.php           ← Admin UI template (SPA shell)
│   ├── admin-style.css          ← Inter-based modern stylesheet
│   └── admin-script.js          ← Tab SPA, wizard, history, overlay, toasts
└── README.md
```

---

## 🚀 Installation

1. Copy the **entire** `Backup Plugin` folder into `wp-content/plugins/orbit-backup/`
2. In WordPress Admin → **Plugins**, activate **Orbit Backup & Restore**
3. Navigate to **Orbit Backup** in the left admin menu

> **Requirement:** PHP `ZipArchive` extension must be enabled. The plugin will block activation and display a clear error if it is missing.

---

## 🎮 Usage

### Creating a Backup

1. Go to **Orbit Backup → Create Backup** tab
2. Click the component toggle cards to select what to include:
   - **Database** — full SQL export of all tables
   - **Plugins** — `wp-content/plugins/`
   - **Themes** — `wp-content/themes/`
   - **Media** — `wp-content/uploads/` (excluding backup storage folder)
   - **Other Files** — everything else in `wp-content/`
3. Click **Start Backup** — a glassmorphism overlay shows progress
4. On completion, a toast notification confirms success and the **History** tab updates

### Restoring a Backup

1. Go to **Orbit Backup → Restore** tab
2. **Step 1 – Upload:** Drag & drop or browse for a `.zip` archive
3. **Step 2 – Verify:** Orbit reads the manifest and displays backup metadata (date, components, original URL, WP version)
4. **Step 3 – Configure:** Optionally set an old → new URL for domain migration
5. **Step 4 – Apply:** Orbit extracts, copies files, imports SQL, and runs URL replacement

### Downloading / Deleting Backups

- Go to the **History** tab
- Every row shows component badges (e.g., `DB` `Plugins` `Media`), size, and date
- Click **Download** for a signed, direct archive download
- Click **Delete** to permanently remove the file and history entry

---

## 🔧 Developer Hooks

### Filters

```php
// Modify backup options before the backup runs
add_filter( 'orbit_backup_options', function( $options ) {
    $options['include_others'] = true; // always include "other files"
    return $options;
} );
```

### Actions

```php
// Fires after a backup is successfully created
add_action( 'orbit_backup_completed', function( $entry ) {
    // $entry = [ 'id', 'filename', 'label', 'created_at', 'size', 'components', 'checksum' ]
    error_log( 'Backup created: ' . $entry['filename'] );
} );

// Fires weekly for automatic backups (WP-Cron)
add_action( 'orbit_backup_cron_event', 'my_custom_pre_backup_hook' );
```

### Programmatic Backup

```php
// Run a backup from your own code
$engine = new Orbit_Backup_Engine();
$result = $engine->run( [
    'include_db'      => true,
    'include_plugins' => false,
    'include_themes'  => true,
    'include_uploads' => true,
    'include_others'  => false,
    'label'           => 'Pre-Deploy',
] );

if ( is_wp_error( $result ) ) {
    error_log( $result->get_error_message() );
} else {
    echo 'Backup saved: ' . $result['filename'];
}
```

### Get Backup History

```php
$history = Orbit_Backup_Engine::get_history();
foreach ( $history as $entry ) {
    echo $entry['filename'] . ' – ' . size_format( $entry['size'] );
}
```

---

## 🎨 Design System

| Token | Value | Use |
|---|---|---|
| `--primary` | `#4f46e5` | Buttons, active states, progress bar |
| `--success` | `#10b981` | Restore actions, success toasts, healthy status |
| `--bg-main` | `#f8fafc` | Page background (Slate-50) |
| `--bg-card` | `#ffffff` | Card surfaces |
| `--text-900` | `#0f172a` | Headings (Slate-900) |
| Typography | **Inter** | Loaded via Google Fonts, weights 300–800 |

---

## 🔒 Security

- All AJAX actions verify `wp_nonce` (`orbit_backup_nonce`)
- All actions require `manage_options` capability
- Backup files stored in `wp-content/orbit-backups/` protected by `.htaccess` (`Options -Indexes`) and an `index.php` sentinel
- Downloads are served via signed WordPress AJAX URLs (10-minute nonce), never direct file links
- File uploads validated by MIME type before processing

---

## ⚙️ Server Requirements

| Requirement | Minimum |
|---|---|
| PHP | 7.4+ |
| WordPress | 5.8+ |
| PHP Extension | `ZipArchive` (php-zip) |
| Disk Space | Enough to store a copy of backed-up directories |
| PHP `upload_max_filesize` | Match the size of your largest backup archive for restores |
| PHP `max_execution_time` | 300s+ recommended for large sites |

---

## 📝 Changelog

### 1.0.0 — 2026-02-21
- Initial release
- Selective backup engine (DB, Plugins, Themes, Uploads, Others)
- Stream-based SQL export
- 4-step restore wizard with URL migration
- Modern Bento-Grid admin UI
- Glassmorphism progress overlay
- History table with download & delete
- SHA-256 integrity checksums
- Hook-based extension API
