<?php
/**
 * Ultra-Secure Orbit Backup Dashboard Template (v2.7.1)
 * Authored by: Umair Javed | Webmicron
 */
defined( 'ABSPATH' ) || exit;

$php_ext_ok = class_exists( 'ZipArchive' );
$disk_usage = 0;
if ( file_exists( ORBIT_BACKUP_STORE_DIR ) ) {
    foreach ( glob( ORBIT_BACKUP_STORE_DIR . '*.zip' ) as $f ) {
        $disk_usage += filesize( $f );
    }
}
$disk_usage_formatted = size_format( $disk_usage, 2 );

// Get server limits for the UI
$max_upload = size_format( wp_max_upload_size() );
$max_exec   = ini_get( 'max_execution_time' );

// Get settings
$sched = get_option( 'orbit_backup_schedule', array( 'enabled' => '0', 'frequency' => 'daily', 'retention' => '30' ) );

// Helper for schedule display
$freq_map = array(
    'daily'   => 'Daily (Every 24 Hours)',
    'weekly'  => 'Weekly (Every 7 Days)',
    'monthly' => 'Monthly (Every 30 Days)'
);
$ret_map = array(
    '30'  => 'Backups older than 30 Days',
    '60'  => 'Backups older than 60 Days',
    '90'  => 'Backups older than 90 Days',
    '180' => 'Backups older than 180 Days'
);
?>

<div id="orbit-app">

    <!-- HEADER -->
    <header class="orb-header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <div class="orb-logo-box">
                <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>
            </div>
            <div>
                <h1>Orbit Backup</h1>
                <p>Advanced Selective Restoration & Archiving</p>
            </div>
        </div>
        <div class="orb-status">
            <span style="color:var(--primary); font-weight:800;">VERIFIED BY WEBMICRON</span>
        </div>
    </header>

    <div class="orb-container">
        
        <!-- NAVIGATION -->
        <nav class="orb-nav">
            <button class="orb-tab active" data-tab="create">CREATE</button>
            <button class="orb-tab" data-tab="schedule">SCHEDULE</button>
            <button class="orb-tab" data-tab="restore">RESTORE</button>
            <button class="orb-tab" data-tab="history">
                HISTORY 
                <span id="orb-history-badge" class="orb-badge" style="display:none;">0</span>
            </button>
        </nav>

        <!-- PANEL: CREATE -->
        <section id="orb-panel-create" class="orb-panel">
            <div class="orb-grid">
                <div class="orb-card">
                    <h2>Manual Archive Configuration</h2>
                    <p>Select the segments of your site to bundle into a recovery package.</p>

                    <div class="orb-selectors-grid">
                        <div class="orb-sel active" data-component="include_db">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3c-4.97 0-9 1.343-9 3s4.03 3 9 3 9-1.343 9-3-4.03-3-9-3z"/><path d="M3 6v12c0 1.657 4.03 3 9 3s9-1.343 9-3V6"/><path d="M3 12c0 1.657 4.03 3 9 3s9-1.343 9-3"/></svg>
                            <h3>Database</h3>
                        </div>
                        
                        <div class="orb-sel active" data-component="include_plugins">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><path d="M16 8L2 22"/><path d="M17.5 15H9"/></svg>
                            <h3>Plugins</h3>
                        </div>
                        
                        <div class="orb-sel active" data-component="include_themes">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                            <h3>Themes</h3>
                        </div>
                        
                        <div class="orb-sel active" data-component="include_uploads">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                            <h3>Media</h3>
                        </div>

                        <div class="orb-sel active" data-component="include_others">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                            <h3>Core Files</h3>
                        </div>
                    </div>

                    <div style="margin-top: 35px; border-top: 1px solid var(--border); padding-top: 30px;">
                        <button class="orb-btn" id="orb-run-backup-btn">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" style="margin-right:10px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                            START NEW ARCHIVE
                        </button>
                    </div>
                </div>

                <div class="orb-sidebar">
                    <div class="orb-card" style="padding: 25px;">
                        <h3 style="font-size: 11px; text-transform: uppercase; color: var(--muted); letter-spacing: 0.1em; margin-bottom: 20px;">Performance Context</h3>
                        <div style="margin-bottom: 25px;">
                            <span style="display: block; font-size: 10px; font-weight: 700; color: var(--muted); margin-bottom: 5px;">MAX UPLOAD SIZE</span>
                            <strong style="font-size: 20px; color: var(--secondary); letter-spacing: -0.01em;"><?php echo esc_html( $max_upload ); ?></strong>
                        </div>
                        <div style="margin-bottom: 25px;">
                            <span style="display: block; font-size: 10px; font-weight: 700; color: var(--muted); margin-bottom: 5px;">EXECUTION TIME</span>
                            <strong style="font-size: 20px; color: var(--secondary); letter-spacing: -0.01em;"><?php echo esc_html( $max_exec ); ?>s</strong>
                        </div>
                        <div style="padding-top: 20px; border-top: 1px solid var(--border);">
                            <span style="display: block; font-size: 10px; font-weight: 700; color: var(--muted); margin-bottom: 5px;">ARCHIVE STORAGE</span>
                            <span id="orb-storage-usage" style="font-size: 14px; color: var(--secondary); font-weight: 600;"><?php echo esc_html( $disk_usage_formatted ); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- PANEL: SCHEDULE -->
        <section id="orb-panel-schedule" class="orb-panel hidden">
            <div class="orb-card">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px;">
                    <div>
                        <h2>Automation Settings</h2>
                        <p>Configure automatic site archives and retention policies.</p>
                    </div>
                    <label class="orb-toggle">
                        <input type="checkbox" id="orb-sched-enabled" <?php checked( $sched['enabled'] ?? '0', '1' ); ?>>
                        <span class="orb-slider"></span>
                        <span style="font-weight: 700; color: var(--secondary); font-size: 13px;">ENABLE AUTOMATION</span>
                    </label>
                </div>

                <div class="orb-schedule-container <?php echo ($sched['enabled'] ?? '0') === '0' ? 'disabled' : ''; ?>">
                    <div class="orb-selectors-grid">
                        <div class="orb-sel <?php echo !empty($sched['include_db']) ? 'active' : ''; ?>" data-component="include_db">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3c-4.97 0-9 1.343-9 3s4.03 3 9 3 9-1.343 9-3-4.03-3-9-3z"/><path d="M3 6v12c0 1.657 4.03 3 9 3s9-1.343 9-3V6"/><path d="M3 12c0 1.657 4.03 3 9 3s9-1.343 9-3"/></svg>
                            <h3>Database</h3>
                        </div>
                        
                        <div class="orb-sel <?php echo !empty($sched['include_plugins']) ? 'active' : ''; ?>" data-component="include_plugins">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><path d="M16 8L2 22"/><path d="M17.5 15H9"/></svg>
                            <h3>Plugins</h3>
                        </div>
                        
                        <div class="orb-sel <?php echo !empty($sched['include_themes']) ? 'active' : ''; ?>" data-component="include_themes">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                            <h3>Themes</h3>
                        </div>
                        
                        <div class="orb-sel <?php echo !empty($sched['include_uploads']) ? 'active' : ''; ?>" data-component="include_uploads">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                            <h3>Media</h3>
                        </div>

                        <div class="orb-sel <?php echo !empty($sched['include_others']) ? 'active' : ''; ?>" data-component="include_others">
                            <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                            <h3>Core Files</h3>
                        </div>
                    </div>

                    <div class="orb-grid" style="grid-template-columns: 1fr 1fr; margin-top: 30px;">
                        <div class="orb-form-group">
                            <label>BACKUP FREQUENCY</label>
                            <div class="orb-custom-select" data-value="<?php echo esc_attr( $sched['frequency'] ?? 'daily' ); ?>">
                                <div class="orb-select-trigger">
                                    <span><?php echo esc_html( $freq_map[ $sched['frequency'] ?? 'daily' ] ); ?></span>
                                </div>
                                <div class="orb-options">
                                    <div class="orb-opt" data-value="daily">Daily (Every 24 Hours)</div>
                                    <div class="orb-opt" data-value="weekly">Weekly (Every 7 Days)</div>
                                    <div class="orb-opt" data-value="monthly">Monthly (Every 30 Days)</div>
                                </div>
                            </div>
                        </div>
                        <div class="orb-form-group">
                            <label>AUTO-CLEANUP (RETENTION)</label>
                            <div class="orb-custom-select" data-value="<?php echo esc_attr( $sched['retention'] ?? '30' ); ?>">
                                <div class="orb-select-trigger">
                                    <span><?php echo esc_html( $ret_map[ $sched['retention'] ?? '30' ] ); ?></span>
                                </div>
                                <div class="orb-options">
                                    <div class="orb-opt" data-value="30">Backups older than 30 Days</div>
                                    <div class="orb-opt" data-value="60">Backups older than 60 Days</div>
                                    <div class="orb-opt" data-value="90">Backups older than 90 Days</div>
                                    <div class="orb-opt" data-value="180">Backups older than 180 Days</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div style="margin-top: 35px; border-top: 1px solid var(--border); padding-top: 30px;">
                        <button class="orb-btn" id="orb-save-schedule-btn">
                            SAVE SCHEDULE SETTINGS
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- PANEL: RESTORE -->
        <section id="orb-panel-restore" class="orb-panel hidden">
            <div class="orb-card orb-restore-card">
                <h2>Import Site Archive</h2>
                <p>Select an Orbit recovery package. Maximum file size: <strong><?php echo esc_html( $max_upload ); ?></strong>.</p>
                
                <label class="orb-upload-area" id="orb-upload-zone" for="orb-file-input">
                    <svg viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    <h2>Drag & Drop Archive</h2>
                    <p>or click here to select a .zip manually</p>
                </label>
                <input type="file" id="orb-file-input" accept=".zip" style="display:none;">

                <div id="orb-file-summary" class="hidden" style="margin-top: 25px; margin-bottom: 25px; padding: 25px; border-radius: 12px; background: var(--grey); border: 1px solid var(--border); text-align: center;">
                    <strong style="color: var(--secondary);">IDENTIFIED:</strong> <span style="font-weight: 700; color: var(--primary);"></span>
                </div>

                <div style="margin-top: 30px;">
                    <button class="orb-btn" id="orb-verify-btn" disabled style="width: 100%; justify-content: center;">
                        VALIDATE ARCHIVE & IMPORT &rarr;
                    </button>
                </div>
            </div>
        </section>

        <!-- PANEL: HISTORY -->
        <section id="orb-panel-history" class="orb-panel hidden">
            <div class="orb-card" style="padding: 0; overflow: hidden;">
                <div style="padding: 35px; border-bottom: 1px solid var(--border);">
                    <h2 style="margin:0;">Site Recovery History</h2>
                </div>
                <div style="overflow-x: auto;">
                    <table class="orb-table">
                        <thead>
                            <tr style="background: #fafafa;">
                                <th>IDENTIFIER</th>
                                <th>DETAILS & SEGMENTS</th>
                                <th style="text-align: right;">OPERATIONS</th>
                            </tr>
                        </thead>
                        <tbody id="orb-history-list">
                            <!-- Populated Dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

    </div>

    <!-- FOOTER SIGNATURE -->
    <div class="orb-container">
        <footer class="orb-footer">
            <a href="https://webmicron.com" target="_blank" class="orb-footer-brand">
                <span>VERIFIED ENGINE BY</span>
                <strong>WEBMICRON</strong>
            </a>
            <div style="font-size: 11px; font-weight: 600; color: var(--muted);">
                &copy; <?php echo date('Y'); ?> Umair Javed. All Rights Reserved.
            </div>
        </footer>
    </div>

    <!-- OVERLAYS -->
    <div class="orb-overlay" id="orb-overlay">
        <div class="orb-progress-box">
            <h2 id="orb-ov-title" style="margin-bottom: 15px; font-weight:700;">Engine Operation Active</h2>
            <div id="orb-ov-percent" class="orb-percent-val">0%</div>
            <div class="orb-progress-track">
                <div id="orb-pfill"></div>
            </div>
            <p style="margin-top: 20px; font-size: 13px;">Processing site segments. Optimized for performance context.</p>
        </div>
    </div>

    <!-- TOAST NOTIFICATION -->
    <div id="orb-toast" class="orb-toast">
        <span id="orb-toast-msg"></span>
    </div>

</div>
