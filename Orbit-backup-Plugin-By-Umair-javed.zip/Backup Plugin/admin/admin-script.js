/**
 * Orbit Backup & Restore — Admin JavaScript SPA
 *
 * Handles: tab navigation, component selection, backup creation,
 * the 4-step restore wizard, history table, progress overlay, and toast notifications.
 */

( function ( $ ) {
    'use strict';

    // ─── State ────────────────────────────────────────────────────────────────
    const state = {
        restoreTmpFile : null,
        restoreManifest: null,
    };

    // ─── Init ─────────────────────────────────────────────────────────────────
    $( document ).ready( function () {
        initTabs();
        initSelectionCards();
        initBackupButton();
        initHistoryTab();
        initRestoreWizard();
        renderHistory( OrbitBackup.history || [] );
    } );

    // ═══════════════════════════════════════════════════ TAB NAVIGATION ══════

    function initTabs() {
        $( '.tab-btn' ).on( 'click', function () {
            const tab = $( this ).data( 'tab' );
            $( '.tab-btn' ).removeClass( 'active' ).attr( 'aria-selected', 'false' );
            $( this ).addClass( 'active' ).attr( 'aria-selected', 'true' );

            $( '.tab-panel' ).hide().attr( 'hidden', true ).removeClass( 'active' );
            $( '#tab-panel-' + tab ).removeAttr( 'hidden' ).addClass( 'active' ).show();
        } );
    }

    // ══════════════════════════════════════════════ COMPONENT SELECTION ═══════

    function initSelectionCards() {
        $( '.select-card' ).on( 'click keydown', function ( e ) {
            // Allow keyboard toggle via Space or Enter.
            if ( e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter' ) return;
            e.preventDefault();

            const $card = $( this );
            const isActive = $card.hasClass( 'active' );
            $card.toggleClass( 'active', ! isActive );
            $card.attr( 'aria-checked', String( ! isActive ) );
        } );
    }

    function getSelectedComponents() {
        const components = {};
        $( '.select-card' ).each( function () {
            const key = $( this ).data( 'component' );
            components[ key ] = $( this ).hasClass( 'active' ) ? '1' : '0';
        } );

        // At least one must be chosen.
        const anySelected = Object.values( components ).some( v => v === '1' );
        return anySelected ? components : null;
    }

    // ═══════════════════════════════════════════════════ CREATE BACKUP ════════

    function initBackupButton() {
        $( '#btn-start-backup' ).on( 'click', function () {
            if ( ! OrbitBackup.zipOk ) {
                showToast( 'ZipArchive is not available. Please contact your host.', 'error' );
                return;
            }

            const components = getSelectedComponents();
            if ( ! components ) {
                showToast( 'Please select at least one component to back up.', 'error' );
                return;
            }

            showOverlay( 'Backup in Progress…', 'Bundling selected components. This may take a few minutes.' );
            animateProgress( 0, 85, 8000 );

            const postData = $.extend( {
                action  : 'orbit_run_backup',
                _wpnonce: OrbitBackup.nonce,
            }, components );

            $.post( OrbitBackup.ajaxUrl, postData )
                .done( function ( response ) {
                    completeProgress();
                    setTimeout( function () {
                        hideOverlay();
                        if ( response.success ) {
                            showToast( response.data.message || 'Backup created!', 'success' );
                            // Prepend to history.
                            const history = OrbitBackup.history || [];
                            history.unshift( response.data.entry );
                            OrbitBackup.history = history.slice( 0, 20 );
                            renderHistory( OrbitBackup.history );
                        } else {
                            showToast( response.data.message || OrbitBackup.strings.error, 'error' );
                        }
                    }, 600 );
                } )
                .fail( function () {
                    hideOverlay();
                    showToast( 'Request failed. Please check your server logs.', 'error' );
                } );
        } );
    }

    // ═══════════════════════════════════════════════════ HISTORY TABLE ════════

    function initHistoryTab() {
        // Refresh button.
        $( '#btn-refresh-history' ).on( 'click', function () {
            const $btn = $( this );
            $btn.prop( 'disabled', true ).text( 'Refreshing…' );

            $.post( OrbitBackup.ajaxUrl, { action: 'orbit_get_history', _wpnonce: OrbitBackup.nonce } )
                .done( function ( res ) {
                    if ( res.success ) {
                        OrbitBackup.history = res.data.history || [];
                        renderHistory( OrbitBackup.history );
                    }
                } )
                .always( function () {
                    $btn.prop( 'disabled', false ).html(
                        '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.95"/></svg> Refresh'
                    );
                } );
        } );
    }

    function renderHistory( history ) {
        const $tbody = $( '#backup-history-body' );
        $tbody.empty();

        // Update badge count.
        const count = history.length;
        $( '#history-count' ).text( count > 0 ? count : '' );

        if ( ! history || ! history.length ) {
            $tbody.html(
                '<tr class="history-empty-row"><td colspan="5">' +
                '<div class="empty-state">' +
                '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>' +
                '<p>No backups yet. Create your first backup!</p>' +
                '</div></td></tr>'
            );
            return;
        }

        $.each( history, function ( i, entry ) {
            const date      = entry.created_at   || '—';
            const size      = entry.size          ? formatBytes( entry.size ) : '—';
            const label     = escHtml( entry.label || 'Manual' );
            const id        = escHtml( entry.id );
            const badges    = buildComponentBadges( entry.components || [] );

            const $tr = $(
                '<tr data-id="' + id + '">' +
                '<td><strong>' + label + '</strong><br><span class="backup-date">' + escHtml( entry.filename ) + '</span></td>' +
                '<td class="backup-date">' + escHtml( date ) + '</td>' +
                '<td class="backup-size">' + size + '</td>' +
                '<td><div class="component-badges">' + badges + '</div></td>' +
                '<td class="backup-actions">' +
                    '<button class="btn-download btn-action-download" data-id="' + id + '">' +
                        '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>' +
                        ' Download' +
                    '</button>' +
                    '<button class="btn-danger btn-action-delete" data-id="' + id + '">' +
                        '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>' +
                        ' Delete' +
                    '</button>' +
                '</td>' +
                '</tr>'
            );

            $tbody.append( $tr );
        } );

        // Download handler.
        $( '.btn-action-download' ).off( 'click' ).on( 'click', function () {
            const bid = $( this ).data( 'id' );
            $( this ).prop( 'disabled', true ).text( 'Preparing…' );

            $.post( OrbitBackup.ajaxUrl, { action: 'orbit_download_backup', backup_id: bid, _wpnonce: OrbitBackup.nonce } )
                .done( function ( res ) {
                    if ( res.success && res.data.download_url ) {
                        window.location.href = res.data.download_url;
                    } else {
                        showToast( res.data.message || 'Download failed.', 'error' );
                    }
                } )
                .always( function () {
                    $( '.btn-action-download[data-id="' + bid + '"]' ).prop( 'disabled', false ).html(
                        '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Download'
                    );
                } );
        } );

        // Delete handler.
        $( '.btn-action-delete' ).off( 'click' ).on( 'click', function () {
            if ( ! window.confirm( OrbitBackup.strings.confirm_delete ) ) return;
            const bid  = $( this ).data( 'id' );
            const $row = $( this ).closest( 'tr' );

            $.post( OrbitBackup.ajaxUrl, { action: 'orbit_delete_backup', backup_id: bid, _wpnonce: OrbitBackup.nonce } )
                .done( function ( res ) {
                    if ( res.success ) {
                        $row.fadeOut( 300, function () { $( this ).remove(); } );
                        OrbitBackup.history = ( OrbitBackup.history || [] ).filter( e => e.id !== bid );
                        $( '#history-count' ).text( OrbitBackup.history.length || '' );
                        showToast( res.data.message || 'Deleted.', 'success' );
                    } else {
                        showToast( res.data.message || 'Delete failed.', 'error' );
                    }
                } );
        } );
    }

    // ═══════════════════════════════════════════════ RESTORE WIZARD ═══════════

    function initRestoreWizard() {
        let selectedFile = null;

        // ── Upload Zone ──────────────────────────────────────────────────────
        const $zone   = $( '#upload-zone' );
        const $input  = $( '#restore-file-input' );
        const $verBtn = $( '#btn-verify-backup' );

        $( '#btn-browse-file' ).on( 'click', function ( e ) {
            e.stopPropagation();
            $input.trigger( 'click' );
        } );

        $zone.on( 'click', function () { $input.trigger( 'click' ); } );

        // Drag & drop
        $zone[0].addEventListener( 'dragover', function ( e ) {
            e.preventDefault();
            $zone.addClass( 'drag-over' );
        } );
        $zone[0].addEventListener( 'dragleave', function () { $zone.removeClass( 'drag-over' ); } );
        $zone[0].addEventListener( 'drop', function ( e ) {
            e.preventDefault();
            $zone.removeClass( 'drag-over' );
            const file = e.dataTransfer.files[0];
            if ( file ) handleFileSelected( file );
        } );

        $input.on( 'change', function () {
            if ( this.files[0] ) handleFileSelected( this.files[0] );
        } );

        $( '#btn-change-file' ).on( 'click', function () {
            selectedFile = null;
            $( '#file-selected' ).hide();
            $zone.show();
            $verBtn.prop( 'disabled', true );
            $input.val( '' );
        } );

        function handleFileSelected( file ) {
            if ( ! file.name.endsWith( '.zip' ) ) {
                showToast( 'Only .zip files are accepted.', 'error' );
                return;
            }
            selectedFile = file;
            $( '#file-selected-name' ).text( file.name );
            $( '#file-selected' ).show();
            $zone.hide();
            $verBtn.prop( 'disabled', false );
        }

        // ── Step 1 → 2: Verify ───────────────────────────────────────────────
        $verBtn.on( 'click', function () {
            if ( ! selectedFile ) { showToast( 'Please select a file first.', 'error' ); return; }

            showOverlay( 'Verifying Archive…', 'Checking integrity and reading manifest…' );
            animateProgress( 0, 90, 4000 );

            const formData = new FormData();
            formData.append( 'action',     'orbit_restore_verify' );
            formData.append( '_wpnonce',   OrbitBackup.nonce );
            formData.append( 'backup_file', selectedFile );

            $.ajax( {
                url        : OrbitBackup.ajaxUrl,
                type       : 'POST',
                data       : formData,
                processData: false,
                contentType: false,
            } )
            .done( function ( res ) {
                completeProgress();
                setTimeout( function () {
                    hideOverlay();
                    if ( res.success ) {
                        state.restoreTmpFile  = res.data.tmp_path;
                        state.restoreManifest = res.data.manifest;
                        renderVerifyResults( res.data.manifest );
                        goToWizardStep( 2 );
                    } else {
                        showToast( res.data.message || 'Verification failed.', 'error' );
                    }
                }, 400 );
            } )
            .fail( function () {
                hideOverlay();
                showToast( 'Upload request failed. The file may be too large (check upload_max_filesize).', 'error' );
            } );
        } );

        // ── Step 2 buttons ───────────────────────────────────────────────────
        $( '#btn-back-1' ).on( 'click', function () { goToWizardStep( 1 ); } );

        $( '#btn-proceed-to-config' ).on( 'click', function () {
            if ( state.restoreManifest && state.restoreManifest.site_url ) {
                $( '#restore-old-url' ).val( state.restoreManifest.site_url );
            }
            goToWizardStep( 3 );
        } );

        // ── Step 3 buttons ───────────────────────────────────────────────────
        $( '#btn-back-2' ).on( 'click', function () { goToWizardStep( 2 ); } );

        $( '#btn-start-restore' ).on( 'click', function () {
            if ( ! window.confirm( OrbitBackup.strings.confirm_restore ) ) return;

            const oldUrl = $( '#restore-old-url' ).val().trim();
            const newUrl = $( '#restore-new-url' ).val().trim();

            goToWizardStep( 4 );
            showOverlay( 'Restoring Backup…', 'Extracting and applying files. Do not close this page.' );
            animateProgress( 0, 90, 20000 );

            $.post( OrbitBackup.ajaxUrl, {
                action   : 'orbit_restore_apply',
                _wpnonce : OrbitBackup.nonce,
                tmp_file : state.restoreTmpFile,
                old_url  : oldUrl,
                new_url  : newUrl,
            } )
            .done( function ( res ) {
                completeProgress();
                setTimeout( function () {
                    hideOverlay();
                    if ( res.success ) {
                        setWizardDone( 'success',
                            'Restore Complete!',
                            res.data.message || 'Your site has been restored. Please clear any caches.'
                        );
                    } else {
                        setWizardDone( 'error',
                            'Restore Failed',
                            res.data.message || 'An error occurred during restore.'
                        );
                    }
                }, 500 );
            } )
            .fail( function () {
                hideOverlay();
                setWizardDone( 'error', 'Request Failed', 'The server did not respond. Check your PHP error logs.' );
            } );
        } );
    }

    function goToWizardStep( step ) {
        // Hide all panels.
        $( '.wizard-panel' ).hide().removeClass( 'active' );
        $( '#wizard-step-' + step ).show().addClass( 'active' );

        // Update step circles.
        $( '.wizard-step' ).each( function () {
            const s = parseInt( $( this ).data( 'step' ), 10 );
            $( this ).removeClass( 'active done' );
            if ( s < step )  $( this ).addClass( 'done' );
            if ( s === step ) $( this ).addClass( 'active' );
        } );

        // Update connectors.
        $( '.wizard-connector' ).each( function ( i ) {
            $( this ).toggleClass( 'done', i < step - 1 );
        } );
    }

    function renderVerifyResults( manifest ) {
        if ( ! manifest ) return;

        const components = ( manifest.components || [] ).map( function ( c ) {
            return buildComponentBadges( [ c ] );
        } ).join( ' ' );

        let html = '';
        const rows = [
            [ 'Plugin Version',  manifest.version   || '—' ],
            [ 'WordPress',       manifest.wp_version || '—' ],
            [ 'Created',         manifest.created_at || '—' ],
            [ 'Original URL',    manifest.site_url   || '—' ],
            [ 'Table Prefix',    manifest.table_prefix || 'wp_' ],
            [ 'Label',           manifest.label      || 'Manual' ],
        ];

        rows.forEach( function ( row ) {
            html += '<div class="verify-row"><span class="verify-row-label">' +
                escHtml( row[0] ) +
                '</span><span class="verify-row-value">' +
                escHtml( row[1] ) +
                '</span></div>';
        } );

        html += '<div class="verify-row"><span class="verify-row-label">Components</span>' +
            '<div class="component-badges" style="flex:1;justify-content:flex-end">' + components + '</div></div>';

        $( '#verify-results' ).html( html );
    }

    function setWizardDone( type, title, message ) {
        const iconHtml = type === 'success'
            ? '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>'
            : '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';

        $( '#done-icon' ).html( iconHtml ).attr( 'class', 'done-icon ' + type );
        $( '#done-title' ).text( title );
        $( '#done-message' ).text( message );

        showToast( type === 'success' ? title : message, type === 'success' ? 'success' : 'error' );
    }

    // ═══════════════════════════════════════════════════════ OVERLAY ══════════

    function showOverlay( title, subtitle ) {
        $( '#overlay-title' ).text( title );
        $( '#overlay-subtitle' ).text( subtitle );
        $( '#overlay-progress' ).css( 'width', '0%' );
        $( '#overlay-pct' ).text( '0%' );
        $( '#orbit-overlay' ).addClass( 'visible' ).attr( 'aria-hidden', 'false' );
        $( 'body' ).css( 'overflow', 'hidden' );
    }

    function hideOverlay() {
        $( '#orbit-overlay' ).removeClass( 'visible' ).attr( 'aria-hidden', 'true' );
        $( 'body' ).css( 'overflow', '' );
    }

    let _progressInterval = null;

    function animateProgress( from, to, duration ) {
        clearInterval( _progressInterval );
        let pct  = from;
        const step = ( to - from ) / ( duration / 100 );
        _progressInterval = setInterval( function () {
            pct = Math.min( pct + step, to );
            const rounded = Math.round( pct );
            $( '#overlay-progress' ).css( 'width', rounded + '%' );
            $( '#overlay-pct' ).text( rounded + '%' );
            if ( pct >= to ) clearInterval( _progressInterval );
        }, 100 );
    }

    function completeProgress() {
        clearInterval( _progressInterval );
        $( '#overlay-progress' ).css( 'width', '100%' );
        $( '#overlay-pct' ).text( '100%' );
    }

    // ════════════════════════════════════════════════════════ TOAST ═══════════

    let _toastTimer = null;

    function showToast( message, type ) {
        type = type || 'info';

        const icons = {
            success: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
            error:   '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
            info:    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
        };

        const $toast = $( '#orbit-toast' );
        $toast
            .attr( 'class', 'orbit-toast toast-' + type )
            .html( ( icons[ type ] || '' ) + '<span>' + escHtml( message ) + '</span>' )
            .addClass( 'visible' );

        clearTimeout( _toastTimer );
        _toastTimer = setTimeout( function () {
            $toast.removeClass( 'visible' );
        }, 4500 );
    }

    // ═══════════════════════════════════════════════════ HELPER UTILS ══════════

    function buildComponentBadges( components ) {
        const map = {
            db      : [ 'DB',      'badge-indigo' ],
            plugins : [ 'Plugins', 'badge-purple' ],
            themes  : [ 'Themes',  'badge-blue'   ],
            uploads : [ 'Media',   'badge-amber'  ],
            others  : [ 'Other',   'badge-slate'  ],
        };

        return components.map( function ( c ) {
            const info = map[ c ] || [ c, 'badge-slate' ];
            return '<span class="badge ' + info[1] + '">' + info[0] + '</span>';
        } ).join( '' );
    }

    function formatBytes( bytes ) {
        if ( bytes === 0 ) return '0 B';
        const units = [ 'B', 'KB', 'MB', 'GB', 'TB' ];
        const i = Math.floor( Math.log( bytes ) / Math.log( 1024 ) );
        return parseFloat( ( bytes / Math.pow( 1024, i ) ).toFixed( 2 ) ) + ' ' + units[ i ];
    }

    function escHtml( str ) {
        if ( typeof str !== 'string' ) str = String( str || '' );
        return str.replace( /&/g, '&amp;' )
                  .replace( /</g, '&lt;' )
                  .replace( />/g, '&gt;' )
                  .replace( /"/g, '&quot;' )
                  .replace( /'/g, '&#039;' );
    }

} )( window.jQuery );
